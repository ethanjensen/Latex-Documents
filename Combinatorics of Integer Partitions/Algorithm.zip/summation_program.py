identities = [(1,6)]

def getval(string):
    valid = False
    while not valid:
        num = input(string)
        try:
            if float(num) == int(num) and int(num) > 0:
                valid = True
        except:
            valid = False
    return int(num)

def getholes(top,index,solution):
    solution.append(0)
    solutionlist = []
    for size in range(1,top+1):
        solution[index] = size
        if top - size == 0:
            solution = solution[:index+1:]
            solutionlist.append(solution)
        else:
            solutionlist = solutionlist + getholes(top-size,index + 1,solution)
    return solutionlist

def newholes(holes):
    newholes = []
    for hole in holes:
        hole.sort()
        newholes.append(hole)
    newholes2 = []
    for hole in holes:
        if hole not in newholes2:
            newholes2.append(hole)
    return newholes2

def fit(block,hole):
    if block <= hole:
        fit == True
    else:
        fit == False
    return fit

def holerange(blocks,holes,blockindex):
    holeindexes = []
    for holeindex in range(0,len(holes)):
        if blocks[blockindex] <= holes[holeindex]:
            holeindexes.append(holeindex)
    return holeindexes

def translate(solution,blocks):
    blockedsolution = [[]]*(max(solution)+1)
    for index in range(0,len(solution)):
        smalllist = blockedsolution[solution[index]].copy()
        smalllist.append(blocks[index])
        blockedsolution[solution[index]] = smalllist
    return blockedsolution

def solve(blocks,holes,blockindex,solution):
    permutations = 0
    if blockindex < len(blocks):
        start = True
        for holeindex in holerange(blocks,holes,blockindex):
            solution[blockindex] = holeindex
            if blockindex == len(blocks)-1:
                blockedsolution = translate(solution,blocks)
                permutations = 1
            else:
                if start:
                    permutations = 0
                    start = False
                tempholes = holes[::]
                tempholes[holeindex] -= blocks[blockindex]
                permutations = permutations + solve(blocks,tempholes,blockindex+1,solution)
    return permutations

def arrangementlist(blocks,holes):
    arrangementlist = []
    for hole in holes:
        permutations = solve(blocks,hole,0,[0]*len(blocks))
        if permutations != 0:
            arrangementlist.append(hole)
            arrangementlist.append(permutations)
    return arrangementlist

def rearrange(blocks, equation):
    for i in range(0,len(equation)):
        x = type(3)
        if type(equation[i]) == x:
            equation[i] = 1*equation[i]
        if equation[i] == blocks:
            multiplier = equation[i+1]
            equation[i+1] = -1
    return (blocks, equation, multiplier)

def gcd(a,b):
    if a*b < 0:
        mult = -1
    else:
        mult = 1
    a = abs(a)
    b = abs(b)
    while a != b and b != 0 and a != 0:
        if a > b:
            a = a % b
        else:
            b = b % a
    a = mult*a
    if a != 0:
        return a
    else:
        return b

def addfractions(fraclist):
    while len(fraclist) > 1:
        newfraclist = fraclist[2::]
        n = fraclist[0][0]*fraclist[1][1]+fraclist[0][1]*fraclist[1][0]
        d = fraclist[0][1]*fraclist[1][1]
        (n,d) = (int(n/gcd(n,d)),int(d/gcd(n,d)))
        newfraclist.insert(0,(n,d))
        fraclist = newfraclist
    fraclist = fraclist[0]
    return fraclist

def converttofraction(blocks,multiplier):
    n = multiplier
    d = 1
    for num in blocks:
        n = n * findsummation(num)[0]
        d = d * findsummation(num)[1]
    (n,d) = (int(n/gcd(n,d)),int(d/gcd(n,d)))
    return (n,d)

def factorial(n):
    if n == 1:
        return 1
    else:
        return n*factorial(n-1)

def multiplysum(numlist):
    numerator = 1
    denominator = 1
    for i in numlist:
        numerator = numerator*findsummation(i)[0]
        denominator = denominator*findsummation(i)[1]
    return (numerator,denominator)

def findsummation(n):
    while len(identities) < n:
        blocks = [1]*n
        holes = getholes(sum(blocks),0,[])
        holes = newholes(holes)
        equation = arrangementlist(blocks,holes)
        (blocks, equation, multiplier) = rearrange(blocks, equation)
        forces = []
        firstforce = addfractions([converttofraction(blocks,1),(-multiplier,factorial(2*len(equation[0])+1))])
        forces.append(firstforce)
        equation = equation[2::]
        while len(equation) > 2:
            blocks = equation[0]
            holes = getholes(sum(blocks),0,[])
            holes = newholes(holes)
            smallequation = arrangementlist(blocks,holes)
            multiplier = smallequation[1]
            newforce = (multiplysum(equation[0]))
            newforce = (-newforce[0]*equation[1],newforce[1]*smallequation[1])
            forces.append(newforce)
            x = type([1])
            mult = smallequation[1]
            smallequation = smallequation[2::]
            for i in range(0,len(equation)):
                for j in range(0,len(smallequation)):
                    if smallequation[j] not in equation and type(smallequation[j]) == x:
                        print("Error")
                    if smallequation[j] == equation[i] and type(smallequation[j]) == x:
                        equation[i+1] = int(equation[i+1] - smallequation[j+1]*equation[1]/mult)
            equation = equation[2::]
        newidentity = addfractions(forces)
        newidentity = (newidentity[0]/gcd(newidentity[0],newidentity[1]*equation[1]),newidentity[1]*equation[1]/gcd(newidentity[0],newidentity[1]*equation[1]))
        newidentity = (int(abs(newidentity[0])),int(abs(newidentity[1])))
        identities.append(newidentity)
    return identities[n-1]

print("Find the infinite sum from n = 1 to infinity of 1/n^2p")
n = getval("Enter a value for p: ")
result = findsummation(n)
if result[0] != 1:
    print(result[0],end='')
print("pi^",2*n,"/",result[1],sep='')
